<?php
	$connection_string = "host=ec2-54-243-214-198.compute-1.amazonaws.com port=5432 dbname=dfkcpo68v5lloa user=irrdzwnekglfuc password=1e8eecdd97b85ee3a49757ecbd88e222d9556add183d08ee6fb6866d77bba6ef";
	$db_connection = pg_connect($connection_string);

	$uid = $_GET["uid"];
	$stat = pg_connection_status($db_connection); 
  	if ($stat === PGSQL_CONNECTION_OK) {
    	echo 'Connection status ok  ';
  	} else {
    	echo 'Connection status bad  ';
  	} 
	
	$result = pg_query($db_connection, $query.";");

	echo ($query."  ");

	if  (!$result) {
		echo "query did not execute  ";
	}	

	while ($row = pg_fetch_array($result)) {	
		echo($row[0]." ".$row[1]." ".$row[2]." ".$row[3]." ".$row[4]." ".$row[5]);
	}

  	pg_close($db_connection);
?>