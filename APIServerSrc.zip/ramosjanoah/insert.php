<?php
	$connection_string = "host=ec2-54-243-214-198.compute-1.amazonaws.com port=5432 dbname=dfkcpo68v5lloa user=irrdzwnekglfuc password=1e8eecdd97b85ee3a49757ecbd88e222d9556add183d08ee6fb6866d77bba6ef";
	$db_connection = pg_connect($connection_string);

	$email = $_POST["email"];
	$fullname = $_POST["fullname"];
	$health = $_POST["health"];
	$muscle = $_POST["muscle"];
	$nationality = $_POST["nationality"];
	$photo = "TBD";

/*
	$email = "testemail";
	$fullname = "testfullname";
	$health = 20;
	$muscle = 20;
	$nationality = "test";
	$photo = "TBD";
*/
	$query = "INSERT INTO users(email, fullname, health, muscle, nationality, photo) 
	VALUES ('$email', '$fullname', $health, $muscle, '$nationality', '$photo')";
	

	echo $query;

	if (pg_query($db_connection, $query)) {
		echo "succes";
		http_response_code(200);

	} else {
		echo "false";
		http_response_code(400);
	}

	// echo ($query."  ");
  	pg_close($db_connection);
?>