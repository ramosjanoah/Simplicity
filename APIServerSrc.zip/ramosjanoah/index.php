<?php
	$connection_string = "host=ec2-54-243-214-198.compute-1.amazonaws.com port=5432 dbname=dfkcpo68v5lloa user=irrdzwnekglfuc password=1e8eecdd97b85ee3a49757ecbd88e222d9556add183d08ee6fb6866d77bba6ef";
	$db_connection = pg_connect($connection_string);


	$stat = pg_connection_status($db_connection); 
  	if ($stat === PGSQL_CONNECTION_OK) {
    	echo 'Connection status ok';
  	} else {
    	echo 'Connection status bad';
  	} 
  	pg_close($db_connection);
?>